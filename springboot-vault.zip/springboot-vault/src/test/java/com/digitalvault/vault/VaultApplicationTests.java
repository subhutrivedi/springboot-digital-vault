package com.digitalvault.vault;

import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;


//@RunWith(SpringRunner.class)
@SpringBootTest
class VaultApplicationTests {

	@Test
	void contextLoads() {
	}

}
